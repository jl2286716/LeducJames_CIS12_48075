<?php include_once("../includes/header.php"); ?>
<center><h1 id="shadow">CHECK OUT</h1></center>
</br>
<center><h3 id="shadow">"Order Confirmation"</h3></center>
<a href="cart.php"><button>CART</button></a>
<?php

?>
<?php include_once("../includes/footer.php"); ?>