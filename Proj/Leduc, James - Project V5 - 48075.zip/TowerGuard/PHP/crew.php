<?php include_once("../includes/header.php"); ?>
<center><h1 id="shadow" >SELECT YOUR GUARD</h1></center>
</br>
<center><h3 id="shadow" >"Choose your leader!"</h3></center>
<div id="select">	<!-- Set this up for "Character Select" -->
	<script>

	</script>
</div>
<?php include_once("../includes/footer.php"); ?>
