<?php include_once("../includes/header.php"); ?>

<center><h1 id="shadow" >WE ARE <i>YOUR</i>...</h1></center>
<center><img src="../images/logo.jpg"></img></center>
</br>
<center><h2>"Welcome to the Tower!"</h2></center>
<br><br>
<center><h2>First timers, please meet with <a href="oracle.php">The Oracle</a>!</h2></center>
<br><br>

<?php include_once("../includes/footer.php"); ?>
