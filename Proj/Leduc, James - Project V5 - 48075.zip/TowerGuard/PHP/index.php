<?php include_once("../includes/openHead.php"); ?>
<br><br><br><br><br>
<center><div><a href="home.php"><img src="../images/symbol.jpg" height="600" width="auto" align="middle" ></img></a></div></center>

<?php include_once("../includes/footer.php"); ?>
