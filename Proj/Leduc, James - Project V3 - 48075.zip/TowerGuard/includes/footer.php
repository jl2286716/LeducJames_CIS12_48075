		<center><address>
			Tower Guard Official &bull; 
			TowerGuard@email.com &bull;
			<a>other.website.com</a> &bull;
			Booking Info: (951) 555-0100
		</address></center>
	</body>
</html>