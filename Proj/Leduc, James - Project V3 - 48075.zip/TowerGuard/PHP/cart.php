<?php include_once("../includes/header.php"); ?>
<center><h1>MERCHANTS OF DEATH</h1></center>
</br>
<center><h3>"Here's your gear!"</h3></center>
<a href="checkout.php"><button>CHECKOUT</button></a>
<script>

</script>
<?php include_once("../includes/footer.php"); ?>