<?php include_once("../includes/header.php"); ?>
<center><h1>TOWER GEAR ~ THE MERCHANTS OF DEATH</h1></center>
</br>
<center><a href="cart.php"><button>CART</button></a></center>
<pre></pre>

<script>

</script>
<center><table width='auto' border='1'>
	<tr>
		<td><a href="https://soundcloud.com/towerguard">
			<img src="../images/Cover_Image.png" height="250" width="250">
		</a></td>
		<td><a href="">
			<img src="../images/placeholder.jpg" height="250" width="250">
		</a></td>
		<td><a href="">
			<img src="../images/placeholder.jpg" height="250" width="250">
		</a></td>
	</tr>
	<tr>
		<td><h3><a href="https://soundcloud.com/towerguard">MUSIC</a></h3></td>
		<td><h3><a href="">POSTERS</a></h3></td>
		<td><h3><a href="">PATCHES</a></h3></td>
	</tr>
	<tr>
		<td><a href="">
			<img src="../images/placeholder.jpg" height="250" width="250">
		</a></td>
		<td><a href="">
			<img src="../images/placeholder.jpg" height="250" width="250">
		</a></td>
		<td><a href="">
			<img src="../images/placeholder.jpg" height="250" width="250">
		</a></td>
	</tr>
	<tr>
		<td><h3><a href="">T-SHIRTS</a></h3></td>
		<td><h3><a href="">HOODIES</a></h3></td>
		<td><h3><a href="">BEANIES</a></h3></td>
	</tr>
</table></center>
<?php include_once("../includes/footer.php"); ?>