<?php include_once("../includes/header.php"); ?>

<center><h2>We are <i>your</i>...</h2></center>
<center><h1>TOWER GUARD</h1></center>
</br>
<center><h2>"Welcome to the Guardians' Tower!"</h2></center>
<br><br>
<center><h2>First timers meet with <a href="oracle.php">The Oracle</a>!</h2></center>
<br><br>

<?php include_once("../includes/footer.php"); ?>
