<center><h1>TOWER GUARD ADMINISTRATION</h1></center><br>
<center><h2>Welcome, Administrator <?php echo "{$_COOKIE['fName']}"; ?>!</h2></center><br><br>
<div id="dash"><br>
	<center><h2><u>Dashboard</u></h2></center><br>
	<center><a href="../PHP/viewUser.php"><button>VIEW/EDIT USERS</button></a></center><br>
	<center><a href="#"><button>VIEW/EDIT ORDERS</button></a></center><br>
	<center><a href="#"><button>VIEW/EDIT MERCH</button></a></center><br>
	<center><a href="#"><button>VIEW/EDIT PHOTOS</button></a></center><br>
	<center><a href="#"><button>VIEW/EDIT VIDEOS</button></a></center><br>
	<center><a href="../PHP/newAdmin.php"><button>ADD/REMOVE ADMIN</button></a></center><br>
</div>
<br><br>
